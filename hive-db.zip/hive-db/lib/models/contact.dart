import 'package:hive/hive.dart';

part 'contact.g.dart';

@override
int get typeId => 0;

@HiveType()
class Contact {
  @HiveField(0)
  final String name;
  @HiveField(1)
  final int age;

  Contact(this.name, this.age);
}
